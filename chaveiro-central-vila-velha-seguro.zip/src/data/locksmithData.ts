export interface Neighborhood {
  id: string;
  name: string;
  badge: string;
  minTime: number;
  maxTime: number;
  routeType: string;
}

export interface EmergencyType {
  id: string;
  title: string;
  subtitle: string;
  equipment: string;
  iconName: string;
}

export const NEIGHBORHOODS: Neighborhood[] = [
  {
    id: 'centro-vv',
    name: 'Centro de Vila Velha',
    badge: '10 a 15 min · Próximo à sede',
    minTime: 8,
    maxTime: 14,
    routeType: 'Deslocamento imediato (base central)',
  },
  {
    id: 'praia-da-costa',
    name: 'Praia da Costa',
    badge: 'Atendimento expresso',
    minTime: 12,
    maxTime: 18,
    routeType: 'Via Av. Champagnat / Hugo Musso',
  },
  {
    id: 'itapua',
    name: 'Itapuã',
    badge: 'Atendimento expresso',
    minTime: 12,
    maxTime: 20,
    routeType: 'Via Av. Jair de Andrade',
  },
  {
    id: 'gloria',
    name: 'Glória / Polo de Confecções',
    badge: 'Atendimento expresso',
    minTime: 10,
    maxTime: 18,
    routeType: 'Via Av. Carlos Lindemberg',
  },
  {
    id: 'coqueiral',
    name: 'Coqueiral de Itaparica',
    badge: 'Rota rápida',
    minTime: 15,
    maxTime: 22,
    routeType: 'Via Rodovia do Sol',
  },
  {
    id: 'praia-gaivotas',
    name: 'Praia das Gaivotas / Itaparica',
    badge: 'Rota rápida',
    minTime: 15,
    maxTime: 24,
    routeType: 'Via Rodovia do Sol',
  },
  {
    id: 'santa-ines',
    name: 'Santa Inês / Cristóvão Colombo',
    badge: 'Rota rápida',
    minTime: 14,
    maxTime: 22,
    routeType: 'Rota expressa municipal',
  },
  {
    id: 'vitoria-centro',
    name: 'Vitória (Centro / Bento Ferreira)',
    badge: 'Travessia Terceira Ponte',
    minTime: 18,
    maxTime: 28,
    routeType: 'Travessia Terceira Ponte / Segunda Ponte',
  },
  {
    id: 'vitoria-praia-canto',
    name: 'Vitória (Praia do Canto / J. da Penha)',
    badge: 'Travessia Terceira Ponte',
    minTime: 20,
    maxTime: 30,
    routeType: 'Travessia Terceira Ponte / Rota Reta da Penha',
  },
];

export const EMERGENCY_TYPES: EmergencyType[] = [
  {
    id: 'residencia',
    title: 'Residência Trancada',
    subtitle: 'Chave esquecida por dentro, tetra ou miolo emperrado',
    equipment: 'Gazua pantográfica e decodificadores não-destrutivos',
    iconName: 'Home',
  },
  {
    id: 'carro',
    title: 'Carro Trancado / Chave Presa',
    subtitle: 'Chave na ignição, pantográfica, travamento acidental',
    equipment: 'Ferramental Lishi automotivo e cunhas infláveis cirúrgicas',
    iconName: 'Car',
  },
  {
    id: 'quebrada',
    title: 'Chave Quebrada no Tambor',
    subtitle: 'Pedaço de lâmina preso dentro da fechadura',
    equipment: 'Extrator micrométrico de palhetas e pinças de precisão',
    iconName: 'Key',
  },
  {
    id: 'cofre',
    title: 'Cofre Trancado / Perda de Código',
    subtitle: 'Cofre mecânico, segredo giratório ou teclado eletrônico',
    equipment: 'Leitor de combinação, decodificador acústico e boroscópio ótico',
    iconName: 'ShieldAlert',
  },
];

export const COMPANY_INFO = {
  name: 'Chaveiro Central',
  city: 'Vila Velha',
  state: 'ES',
  phoneWhatsApp: '(27) 99281-2258',
  phoneWhatsAppClean: '5527992812258',
  phoneLandline: '+55 (27) 3329-2074',
  phoneLandlineClean: '552733292074',
  address: 'Rua Henrique Moscoso, 1100 - Lj 03',
  district: 'Centro de Vila Velha',
  zip: '29100-020',
  hours: 'Segunda a Domingo até às 22:00 hs',
  plantaoNotice: 'Plantão estendido pós horário comercial inclusive feriados',
  coverage: 'Vila Velha e Grande Vitória',
  radius: 'Até 30 km',
  foundationYears: '+18 anos',
  // Preencha com os dados reais da empresa; o rodapé só exibe o CNPJ se ele estiver preenchido.
  legalName: '',
  cnpj: '',
};
