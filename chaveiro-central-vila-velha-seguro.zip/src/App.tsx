import React, { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { MetricsBar } from './components/MetricsBar';
import { EmergencySimulator } from './components/EmergencySimulator';
import { ServicesGrid } from './components/ServicesGrid';
import { AboutSection } from './components/AboutSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { FloatingEmergencyBadge } from './components/FloatingEmergencyBadge';
import { MapsModal } from './components/MapsModal';
import { QuickDispatchModal } from './components/QuickDispatchModal';

export default function App() {
  const [isMapOpen, setIsMapOpen] = useState(false);
  const [isQuickDispatchOpen, setIsQuickDispatchOpen] = useState(false);
  const [selectedServiceForModal, setSelectedServiceForModal] = useState<string>(
    'Abertura de Porta Residencial (Chave Esquecida/Trancada)'
  );
  const [preFilledNeighborhood, setPreFilledNeighborhood] = useState<string>('Centro de Vila Velha');
  const [preFilledService, setPreFilledService] = useState<string>(
    'Abertura de Porta Residencial (Chave Esquecida/Trancada)'
  );

  const handleContactClick = () => {
    const contactElem = document.getElementById('contato');
    if (contactElem) {
      contactElem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSelectServiceFromCard = (serviceName: string) => {
    setSelectedServiceForModal(serviceName);
    setIsQuickDispatchOpen(true);
  };

  const handleSimulatorPreFill = (neighborhoodName: string, serviceTitle: string) => {
    setPreFilledNeighborhood(neighborhoodName);
    setPreFilledService(serviceTitle);
    const contactElem = document.getElementById('contato');
    if (contactElem) {
      contactElem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#0B0F17] text-slate-100 flex flex-col selection:bg-amber-400 selection:text-slate-950">
      {/* Top Navigation */}
      <Header onContactClick={handleContactClick} />

      {/* Main Content Sections */}
      <main className="flex-1">
        {/* Hero Section */}
        <Hero
          onContactClick={handleContactClick}
          onOpenMap={() => setIsMapOpen(true)}
        />

        {/* 4-Item Statistics Bar */}
        <MetricsBar />

        {/* Interactive Emergency Arrival Simulator */}
        <EmergencySimulator onPreFillRequest={handleSimulatorPreFill} />

        {/* 4 Specialized Non-Destructive Services */}
        <ServicesGrid onSelectService={handleSelectServiceFromCard} />

        {/* About & Technical Rigor Comparison */}
        <AboutSection onOpenMap={() => setIsMapOpen(true)} />

        {/* Official Contact & Lead Capture Section */}
        <ContactSection
          onOpenMap={() => setIsMapOpen(true)}
          preFilledNeighborhood={preFilledNeighborhood}
          preFilledService={preFilledService}
        />
      </main>

      {/* Footer */}
      <Footer onOpenMap={() => setIsMapOpen(true)} />

      {/* Floating Emergency Plantão Badge */}
      <FloatingEmergencyBadge />

      {/* Google Maps / Base Location Modal */}
      <MapsModal isOpen={isMapOpen} onClose={() => setIsMapOpen(false)} />

      {/* Quick Service Dispatch Modal */}
      <QuickDispatchModal
        isOpen={isQuickDispatchOpen}
        onClose={() => setIsQuickDispatchOpen(false)}
        defaultService={selectedServiceForModal}
        defaultNeighborhood={preFilledNeighborhood}
      />
    </div>
  );
}
