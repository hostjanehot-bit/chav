import React from 'react';
import { ArrowRight, Phone, CheckCircle2, MapPin, Award } from 'lucide-react';
import { COMPANY_INFO } from '../data/locksmithData';
import heroImg from '../assets/images/hero.webp';

interface HeroProps {
  onContactClick: () => void;
  onOpenMap: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onContactClick, onOpenMap }) => {
  return (
    <section id="inicio" className="relative pt-8 pb-16 lg:pt-14 lg:pb-20 overflow-hidden">
      {/* Background radial highlight */}
      <div className="absolute top-0 left-1/4 -translate-x-1/2 w-[600px] h-[500px] bg-amber-500/5 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute top-1/3 right-10 w-[450px] h-[450px] bg-sky-900/10 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          
          {/* Left Column: Copy & Actions */}
          <div className="lg:col-span-7 flex flex-col items-start">
            {/* Top Super-Kicker */}
            <div className="text-amber-400 font-bold text-xs uppercase tracking-widest mb-4">
              VILA VELHA &amp; GRANDE VITÓRIA • PLANTÃO ATÉ 22:00H • 7 DIAS POR SEMANA
            </div>

            {/* Display Headline */}
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-[3.25rem] font-black text-white leading-[1.12] tracking-tight mb-6 font-['Montserrat']">
              Acesso rápido. Abertura sem danos sempre que possível. Chaveiro de precisão.
            </h1>

            {/* Subtitle / Description */}
            <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-2xl mb-8">
              Trancado para fora de casa, com a chave do carro presa na ignição ou precisando de abertura técnica de cofre? Atendimento pós-horário comercial de segunda a domingo até às 22:00h. Deslocamento rápido para o Centro, Praia da Costa, Itapuã e toda a Grande Vitória com instrumental não-destrutivo.
            </p>

            {/* Call to Action Buttons */}
            <div className="flex flex-wrap items-center gap-4 mb-8 w-full sm:w-auto">
              <button
                onClick={onContactClick}
                type="button"
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-xs sm:text-sm font-extrabold uppercase tracking-wider text-slate-950 bg-amber-400 hover:bg-amber-300 active:bg-amber-500 rounded-full shadow-[0_4px_20px_rgba(245,158,11,0.25)] transition-all transform hover:-translate-y-0.5 whitespace-nowrap focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-400"
              >
                <span>ENTRAR EM CONTATO</span>
                <ArrowRight className="w-4 h-4 stroke-[2.5]" />
              </button>

              <a
                href={`tel:${COMPANY_INFO.phoneWhatsAppClean}`}
                className="inline-flex items-center justify-center gap-2.5 px-6 py-3.5 text-xs sm:text-sm font-semibold text-slate-200 hover:text-white bg-[#111827] hover:bg-slate-800 border border-slate-700/80 rounded-full transition-colors whitespace-nowrap focus:outline-none focus-visible:ring-2 focus-visible:ring-slate-400"
              >
                <Phone className="w-4 h-4 text-amber-400" />
                <span>Ligar Agora: {COMPANY_INFO.phoneWhatsApp}</span>
              </a>
            </div>

            {/* Three Pillar Guarantees */}
            <div className="flex flex-wrap items-center gap-x-6 gap-y-2.5 text-xs sm:text-sm text-slate-300">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Disponível prontamente em minutos de serviço</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Sem arrombamentos ou danos na porta</span>
              </div>
              <button
                onClick={onOpenMap}
                type="button"
                className="flex items-center gap-2 hover:text-amber-400 text-left transition-colors cursor-pointer group"
              >
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 group-hover:text-amber-400" />
                <span className="underline decoration-slate-600 underline-offset-4 group-hover:decoration-amber-400">
                  Sede física na Henrique Moscoso
                </span>
              </button>
            </div>
          </div>

          {/* Right Column: Workshop Image & Official Base Card */}
          <div className="lg:col-span-5">
            <div className="relative rounded-2xl overflow-hidden border border-slate-700/60 bg-[#121826] shadow-2xl group">
              {/* Image Frame */}
              <div className="aspect-[4/3] w-full overflow-hidden bg-slate-900 relative">
                <img
                  src={heroImg}
                  alt="Bancada profissional de chaveiro com pinos e gazua cirúrgica"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                  loading="eager"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0B0F17] via-transparent to-transparent opacity-80" />
              </div>

              {/* Bottom Operational Base Info */}
              <div className="p-4 sm:p-5 bg-[#121826]/95 border-t border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div>
                  <span className="block text-[10px] uppercase font-bold tracking-wider text-slate-400">
                    BASE OPERACIONAL
                  </span>
                  <div className="flex items-center gap-1.5 text-slate-200 font-medium mt-0.5">
                    <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span>{COMPANY_INFO.address} - {COMPANY_INFO.district}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-start sm:self-auto bg-slate-900/90 border border-amber-500/30 px-3 py-1.5 rounded-lg text-amber-400 shrink-0">
                  <Award className="w-4 h-4" />
                  <div className="text-[11px] font-bold leading-tight">
                    <span>+18 ANOS DE TRADIÇÃO</span>
                    <span className="block text-[9px] text-slate-400 font-normal">Atendimento de elite</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
