import React from 'react';
import { KeyRound, MapPin, Phone, Clock, ArrowRight } from 'lucide-react';
import { COMPANY_INFO } from '../data/locksmithData';

interface FooterProps {
  onOpenMap: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenMap }) => {
  return (
    <footer className="bg-[#070A10] border-t border-slate-800 text-slate-400 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 lg:gap-12">
          
          {/* Column 1: Brand & Contact summary (md:col-span-5) */}
          <div className="md:col-span-5 space-y-4">
            <div className="flex items-center gap-2.5 text-white font-extrabold text-lg">
              <span className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
                <KeyRound className="w-4 h-4 stroke-[2.2]" />
              </span>
              <span className="font-['Montserrat'] tracking-tight">
                Chaveiro <span className="text-amber-400">Central</span>
              </span>
            </div>

            <p className="text-slate-400 text-xs leading-relaxed max-w-sm">
              Plantão de atendimento pós horário comercial de segunda a domingo até às 22:00 hs. Especialistas em aberturas técnicas sem danos para residências, automóveis e cofres em Vila Velha e Vitória.
            </p>

            <div className="space-y-2 pt-2 text-slate-300">
              <div className="flex items-start gap-2">
                <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                <span>{COMPANY_INFO.address} - {COMPANY_INFO.district}, ES</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span>Comercial: {COMPANY_INFO.phoneLandline} • Plantão: {COMPANY_INFO.phoneWhatsApp}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span>Segunda a Domingo com plantão até 22:00 hs</span>
              </div>
            </div>
          </div>

          {/* Column 2: Navegação (md:col-span-3) */}
          <div className="md:col-span-3">
            <h4 className="text-white font-bold uppercase text-[11px] tracking-wider mb-4 font-['Montserrat']">
              NAVEGAÇÃO
            </h4>
            <ul className="space-y-2.5">
              <li>
                <a href="#inicio" className="hover:text-amber-400 transition-colors">
                  Início
                </a>
              </li>
              <li>
                <a href="#servicos" className="hover:text-amber-400 transition-colors">
                  Serviços
                </a>
              </li>
              <li>
                <a href="#sobre" className="hover:text-amber-400 transition-colors">
                  Sobre Nós
                </a>
              </li>
              <li>
                <a href="#contato" className="hover:text-amber-400 transition-colors">
                  Contato &amp; Localização
                </a>
              </li>
              <li>
                <a href="#simulador" className="hover:text-amber-400 transition-colors">
                  Simulador de Chegada
                </a>
              </li>
            </ul>
          </div>

          {/* Column 3: Especialidades em Vila Velha (md:col-span-4) */}
          <div className="md:col-span-4">
            <h4 className="text-amber-400 font-bold uppercase text-[11px] tracking-wider mb-4 font-['Montserrat']">
              ESPECIALIDADES EM VILA VELHA
            </h4>
            <ul className="space-y-2 text-slate-400">
              <li>• Abertura de portas residenciais e tetra com técnica não-destrutiva</li>
              <li>• Confecção e codificação de chaves automotivas</li>
              <li>• Destravamento técnico e reprogramação de cofres</li>
              <li>• Instalação de fechaduras digitais e biométricas</li>
              <li>• Plantão com chegada rápida de 15 a 25 minutos</li>
            </ul>

            <div className="mt-5">
              <button
                onClick={onOpenMap}
                type="button"
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-amber-400 hover:text-amber-300 transition-colors group cursor-pointer"
              >
                <span>Ver no Google Maps</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </div>

        </div>

        {/* Bottom copyright & location bar */}
        <div className="mt-12 pt-6 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] text-slate-500">
          <div className="flex flex-col sm:flex-row items-center gap-1 sm:gap-3">
            <span>
              © {new Date().getFullYear()} {COMPANY_INFO.name} - Todos os direitos reservados.
            </span>
            {COMPANY_INFO.cnpj && (
              <span>
                {COMPANY_INFO.legalName ? `${COMPANY_INFO.legalName} | ` : ''}CNPJ {COMPANY_INFO.cnpj}
              </span>
            )}
            <a
              href="/privacidade.html"
              target="_blank"
              rel="noopener noreferrer"
              className="underline hover:text-amber-400 transition-colors"
            >
              Política de Privacidade
            </a>
          </div>
          <div>
            Centro de Vila Velha - Espírito Santo | CEP {COMPANY_INFO.zip}
          </div>
        </div>
      </div>
    </footer>
  );
};
