import React, { useState } from 'react';
import { X, MessageCircle, CheckCircle2, ShieldCheck } from 'lucide-react';
import { COMPANY_INFO, NEIGHBORHOODS } from '../data/locksmithData';

interface QuickDispatchModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultService?: string;
  defaultNeighborhood?: string;
}

export const QuickDispatchModal: React.FC<QuickDispatchModalProps> = ({
  isOpen,
  onClose,
  defaultService = 'Abertura de Porta Residencial (Chave Esquecida/Trancada)',
  defaultNeighborhood = 'Centro de Vila Velha',
}) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [neighborhood, setNeighborhood] = useState(defaultNeighborhood);
  const [service, setService] = useState(defaultService);
  const [isSuccess, setIsSuccess] = useState(false);

  React.useEffect(() => {
    if (defaultService) setService(defaultService);
    if (defaultNeighborhood) setNeighborhood(defaultNeighborhood);
  }, [defaultService, defaultNeighborhood]);

  if (!isOpen) return null;

  // O site não tem servidor: o chamado só é enviado quando a pessoa toca em "enviar" no WhatsApp.
  const openWhatsApp = () => {
    const text = encodeURIComponent(
      `Olá, Chaveiro Central! Solicitação de atendimento rápido:\nNome: ${name || 'Cliente'}\nTelefone: ${phone || 'Não informado'}\nBairro: ${neighborhood}\nServiço: ${service}`
    );
    window.open(`https://wa.me/${COMPANY_INFO.phoneWhatsAppClean}?text=${text}`, '_blank', 'noopener,noreferrer');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    openWhatsApp();
    setIsSuccess(true);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
    >
      <div
        className="bg-[#121826] border border-amber-500/40 w-full max-w-lg rounded-2xl p-6 shadow-2xl relative text-slate-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3.5 border-b border-slate-800">
          <div>
            <span className="text-[10px] uppercase font-bold tracking-wider text-amber-400 block">
              PLANTÃO ATÉ 22:00H
            </span>
            <h3 className="font-bold text-white text-lg font-['Montserrat']">
              Acionar Socorro Técnico Imediato
            </h3>
          </div>
          <button
            onClick={onClose}
            type="button"
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
            aria-label="Fechar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        {isSuccess ? (
          <div className="py-8 text-center space-y-4">
            <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
            <h4 className="text-xl font-bold text-white font-['Montserrat']">
              Falta só enviar no WhatsApp
            </h4>
            <p className="text-xs sm:text-sm text-slate-300 max-w-sm mx-auto">
              Abrimos o WhatsApp com o seu chamado para <strong>{neighborhood}</strong>. Toque em <strong>enviar</strong> lá para concluir. Se a janela não abriu, ligue para{' '}
              <a href={`tel:${COMPANY_INFO.phoneWhatsAppClean}`} className="font-bold text-amber-400 underline">
                {COMPANY_INFO.phoneWhatsApp}
              </a>.
            </p>
            <div className="pt-3">
              <button
                onClick={() => {
                  setIsSuccess(false);
                  onClose();
                }}
                type="button"
                className="px-6 py-2.5 rounded-xl bg-amber-400 text-slate-950 font-bold text-xs uppercase"
              >
                Concluir
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="py-4 space-y-3.5 text-xs">
            <div>
              <label className="block text-[11px] font-bold text-slate-300 mb-1">
                SEU NOME OU IDENTIFICAÇÃO
              </label>
              <input
                maxLength={80}
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ex: Roberto Almeida"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-amber-400"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">
                  WHATSAPP / TELEFONE
                </label>
                <input
                  maxLength={20}
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="(27) 99999-9999"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">
                  SEU BAIRRO
                </label>
                <select
                  value={neighborhood}
                  onChange={(e) => setNeighborhood(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm focus:outline-none focus:border-amber-400 cursor-pointer"
                >
                  {NEIGHBORHOODS.map((n) => (
                    <option key={n.id} value={n.name}>
                      {n.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-300 mb-1">
                SERVIÇO REQUERIDO
              </label>
              <select
                value={service}
                onChange={(e) => setService(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm focus:outline-none focus:border-amber-400 cursor-pointer"
              >
                <option value="Abertura de Porta Residencial (Chave Esquecida/Trancada)">
                  Abertura de Porta Residencial (Chave Esquecida/Trancada)
                </option>
                <option value="Abertura Automotiva / Chave Presa">
                  Abertura Automotiva / Chave Presa
                </option>
                <option value="Troca / Cópia de Segredo de Cilindro">
                  Troca / Cópia de Segredo de Cilindro
                </option>
                <option value="Abertura de Cofre / Recuperação de Segredo">
                  Abertura de Cofre / Recuperação de Segredo
                </option>
                <option value="Instalação de Fechadura Digital / Eletrônica">
                  Instalação de Fechadura Digital / Eletrônica
                </option>
                <option value="Chave Mestra Corporativa">
                  Chave Mestra Corporativa
                </option>
                <option value="Chave Quebrada no Tambor">
                  Chave Quebrada no Tambor
                </option>
              </select>
            </div>

            <div className="pt-2 flex items-center gap-1.5 text-[11px] text-emerald-400">
              <ShieldCheck className="w-4 h-4 shrink-0" />
              <span>Abertura sem danos ao cilindro ou à porta sempre que tecnicamente possível.</span>
            </div>

            <div className="pt-3 flex flex-col sm:flex-row gap-2.5">
              <button
                type="submit"
                className="flex-1 py-3 px-4 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-extrabold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Enviar pelo WhatsApp</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
