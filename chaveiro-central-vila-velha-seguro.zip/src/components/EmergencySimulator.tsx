import React, { useState } from 'react';
import { Send, CheckCircle2, ShieldCheck, Home, Car, Key, ShieldAlert } from 'lucide-react';
import { NEIGHBORHOODS, EMERGENCY_TYPES, COMPANY_INFO } from '../data/locksmithData';

interface EmergencySimulatorProps {
  onPreFillRequest: (neighborhood: string, service: string) => void;
}

export const EmergencySimulator: React.FC<EmergencySimulatorProps> = ({ onPreFillRequest }) => {
  const [selectedNeighborhoodId, setSelectedNeighborhoodId] = useState<string>('gloria');
  const [selectedEmergencyId, setSelectedEmergencyId] = useState<string>('residencia');

  const selectedNeighborhood =
    NEIGHBORHOODS.find((n) => n.id === selectedNeighborhoodId) || NEIGHBORHOODS[0];
  const selectedEmergency =
    EMERGENCY_TYPES.find((e) => e.id === selectedEmergencyId) || EMERGENCY_TYPES[0];

  const handleWhatsAppDispatch = () => {
    const text = encodeURIComponent(
      `Olá, Chaveiro Central! Preciso de atendimento emergencial em ${selectedNeighborhood.name}.\nProblema: ${selectedEmergency.title} (${selectedEmergency.subtitle}).\nTempo estimado no simulador: ${selectedNeighborhood.minTime} a ${selectedNeighborhood.maxTime} min. Pode despachar o plantonista?`
    );
    window.open(`https://wa.me/${COMPANY_INFO.phoneWhatsAppClean}?text=${text}`, '_blank', 'noopener,noreferrer');
  };

  const getEmergencyIcon = (iconName: string) => {
    switch (iconName) {
      case 'Home':
        return <Home className="w-4 h-4 text-amber-400 shrink-0" />;
      case 'Car':
        return <Car className="w-4 h-4 text-amber-400 shrink-0" />;
      case 'Key':
        return <Key className="w-4 h-4 text-amber-400 shrink-0" />;
      case 'ShieldAlert':
        return <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />;
      default:
        return <Key className="w-4 h-4 text-amber-400 shrink-0" />;
    }
  };

  return (
    <section id="simulador" className="py-12 lg:py-16 bg-[#080C14] border-y border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-10">
          <div className="text-amber-400 font-bold text-xs uppercase tracking-widest mb-2">
            PLANTÃO DE RESPOSTA RÁPIDA • ATÉ 22:00H DIARIAMENTE
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight mb-3 font-['Montserrat']">
            Simulador de Atendimento Emergencial
          </h2>
          <p className="text-sm sm:text-base text-slate-300">
            Selecione a sua localização e o tipo de problema para verificar o tempo estimado de chegada saindo da nossa sede física no Centro de Vila Velha.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Selection Columns (12 / 7 cols) */}
          <div className="lg:col-span-7 space-y-8">
            
            {/* 1. SELECIONE O SEU BAIRRO */}
            <div>
              <h3 className="text-xs sm:text-sm font-bold uppercase tracking-wider text-slate-200 mb-3 flex items-center gap-2">
                <span className="text-amber-400">1.</span> SELECIONE O SEU BAIRRO OU REGIÃO:
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
                {NEIGHBORHOODS.map((item) => {
                  const isSelected = item.id === selectedNeighborhoodId;
                  return (
                    <button
                      key={item.id}
                      onClick={() => setSelectedNeighborhoodId(item.id)}
                      type="button"
                      className={`text-left p-3 rounded-xl border transition-all text-xs font-medium cursor-pointer ${
                        isSelected
                          ? 'bg-amber-500/10 border-amber-500/80 text-white shadow-[0_0_15px_rgba(245,158,11,0.15)] ring-1 ring-amber-500/50'
                          : 'bg-[#121826] border-slate-800 text-slate-300 hover:border-slate-700 hover:text-white'
                      }`}
                    >
                      <div className="font-semibold text-slate-100 mb-0.5">{item.name}</div>
                      <div className={`text-[11px] ${isSelected ? 'text-amber-400' : 'text-slate-400'}`}>
                        {item.badge}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 2. QUAL É A SUA URGÊNCIA NO MOMENTO? */}
            <div>
              <h3 className="text-xs sm:text-sm font-bold uppercase tracking-wider text-slate-200 mb-3 flex items-center gap-2">
                <span className="text-amber-400">2.</span> QUAL É A SUA URGÊNCIA NO MOMENTO?
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {EMERGENCY_TYPES.map((type) => {
                  const isSelected = type.id === selectedEmergencyId;
                  return (
                    <button
                      key={type.id}
                      onClick={() => setSelectedEmergencyId(type.id)}
                      type="button"
                      className={`text-left p-4 rounded-xl border transition-all cursor-pointer flex gap-3 ${
                        isSelected
                          ? 'bg-amber-500/10 border-amber-500/80 shadow-[0_0_15px_rgba(245,158,11,0.15)] ring-1 ring-amber-500/50'
                          : 'bg-[#121826] border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 shrink-0 self-start">
                        {getEmergencyIcon(type.iconName)}
                      </div>
                      <div>
                        <div className="text-xs sm:text-sm font-bold text-slate-100 mb-1">
                          {type.title}
                        </div>
                        <div className="text-[11px] text-slate-400 leading-snug">
                          {type.subtitle}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

          </div>

          {/* Right Operational Estimate Output Card */}
          <div className="lg:col-span-5">
            <div className="rounded-2xl border border-amber-500/40 bg-[#121826] p-6 lg:p-7 shadow-[0_8px_30px_rgba(0,0,0,0.6)] relative overflow-hidden">
              
              {/* Card Header */}
              <div className="flex items-center justify-between pb-5 border-b border-slate-800">
                <div>
                  <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block">
                    ESTIMATIVA OPERACIONAL
                  </span>
                  <div className="text-xs sm:text-sm font-bold text-amber-400 mt-0.5">
                    Plantão Pronto para Saída
                  </div>
                </div>
                <div className="w-8 h-8 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center">
                  <Send className="w-4 h-4" />
                </div>
              </div>

              {/* Arrival Time Callout */}
              <div className="py-5 border-b border-slate-800">
                <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block mb-1">
                  TEMPO DE CHEGADA ESTIMADO NO LOCAL
                </span>
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl sm:text-4xl font-black text-white font-['Montserrat'] tracking-tight tabular-nums">
                    {selectedNeighborhood.minTime} a {selectedNeighborhood.maxTime} min
                  </span>
                </div>
                <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1.5">
                  <span className="inline-block w-2 h-2 rounded-full bg-emerald-400"></span>
                  <span>Estimativa; o tempo real varia conforme trânsito e demanda</span>
                </div>
              </div>

              {/* Technical Details Grid */}
              <div className="py-5 border-b border-slate-800 space-y-3 text-xs">
                <div className="flex justify-between items-start gap-2">
                  <span className="text-slate-400 shrink-0">Origem:</span>
                  <span className="text-slate-200 font-medium text-right">
                    Rua Henrique Moscoso, 1100 - Centro de Vila Velha
                  </span>
                </div>

                <div className="flex justify-between items-start gap-2">
                  <span className="text-slate-400 shrink-0">Região de Atendimento:</span>
                  <span className="text-amber-400 font-bold text-right">
                    {selectedNeighborhood.name}
                  </span>
                </div>

                <div className="flex justify-between items-start gap-2">
                  <span className="text-slate-400 shrink-0">Tipo de Bloqueio:</span>
                  <span className="text-slate-200 font-medium text-right">
                    {selectedEmergency.title}
                  </span>
                </div>

                <div className="flex justify-between items-start gap-2">
                  <span className="text-slate-400 shrink-0">Equipamento Mobilizado:</span>
                  <span className="text-slate-300 text-right font-medium">
                    {selectedEmergency.equipment}
                  </span>
                </div>

                <div className="flex justify-between items-start gap-2">
                  <span className="text-slate-400 shrink-0">Método:</span>
                  <span className="text-emerald-400 font-semibold text-right flex items-center justify-end gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    Sem danos sempre que tecnicamente possível
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-5 space-y-3">
                <button
                  onClick={handleWhatsAppDispatch}
                  type="button"
                  className="w-full py-3.5 px-4 text-xs sm:text-sm font-extrabold uppercase tracking-wider text-slate-950 bg-amber-400 hover:bg-amber-300 active:bg-amber-500 rounded-xl transition-all shadow-[0_4px_20px_rgba(245,158,11,0.25)] flex items-center justify-center gap-2 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-400"
                >
                  <Send className="w-4 h-4 stroke-[2.2]" />
                  <span>DESPACHAR CHAVEIRO VIA WHATSAPP</span>
                </button>

                <div className="text-center">
                  <a
                    href={`tel:${COMPANY_INFO.phoneWhatsAppClean}`}
                    className="text-[11px] text-slate-400 hover:text-amber-400 transition-colors inline-block"
                  >
                    Clique direto para falar com o plantonista: <span className="font-semibold text-slate-300 underline">{COMPANY_INFO.phoneWhatsApp}</span>
                  </a>
                </div>

                <button
                  onClick={() => onPreFillRequest(selectedNeighborhood.name, selectedEmergency.title)}
                  type="button"
                  className="w-full text-center text-[11px] font-medium text-slate-400 hover:text-slate-200 underline pt-1 cursor-pointer"
                >
                  Ou preencher formulário de atendimento no site
                </button>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
