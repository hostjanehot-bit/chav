import React from 'react';
import { MapPin, Clock, AlertTriangle, ShieldCheck, Check } from 'lucide-react';
import { COMPANY_INFO } from '../data/locksmithData';

interface AboutSectionProps {
  onOpenMap: () => void;
}

export const AboutSection: React.FC<AboutSectionProps> = ({ onOpenMap }) => {
  return (
    <section id="sobre" className="py-16 lg:py-24 bg-[#080C14] border-t border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-12 sm:mb-16">
          <div className="text-amber-400 font-bold text-xs uppercase tracking-widest mb-3">
            SOBRE O CHAVEIRO CENTRAL • CENTRO DE VILA VELHA
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight mb-4 font-['Montserrat']">
            A diferença entre abrir uma porta e danificar o seu patrimônio.
          </h2>
          <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
            Em momentos de emergência, a pressa pode levar a escolhas desastrosas. Chaveiros desqualificados usam furadeiras, pé-de-cabra ou alicates de pressão, destruindo fechaduras e portas caras. No Chaveiro Central, nosso princípio fundamental é a precisão não-invasiva.
          </p>
        </div>

        {/* Split Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Left Large Card: Strategic Base & Protocol */}
          <div className="lg:col-span-7 bg-[#121826] border border-slate-800 rounded-2xl p-6 sm:p-8 flex flex-col justify-between">
            <div>
              <span className="text-[11px] uppercase font-bold tracking-wider text-amber-400 block mb-2">
                COMPROMISSO TÉCNICO INEGOCIÁVEL
              </span>
              <h3 className="text-xl sm:text-2xl font-bold text-white mb-5 font-['Montserrat'] leading-snug">
                Localização estratégica para resposta rápida em até 25 minutos.
              </h3>

              <div className="space-y-4 text-xs sm:text-sm text-slate-300 leading-relaxed">
                <p>
                  Com nossa base operacional estabelecida no coração comercial da cidade — na <strong className="text-white">Rua Henrique Moscoso, 1100, Loja 03</strong> —, nossas viaturas e motocicletas de socorro contam com rota desobstruída para a Praia da Costa, Itapuã, Glória, Coqueiral de Itaparica e travessia ágil da Terceira Ponte rumo a Vitória.
                </p>
                <p>
                  Quando o relógio marca 18:00h e o comércio tradicional encerra o expediente, nosso plantão especializado assume o comando. Mantemos profissionais de sobreaviso e ferramental a postos todos os dias da semana, incluindo sábados, domingos e feriados, <strong className="text-amber-400">ininterruptamente até às 22:00h</strong>.
                </p>
                <p>
                  Todo atendimento é realizado por técnicos identificados, garantindo a sua tranquilidade e a segurança de sua família ou empresa.
                </p>
              </div>
            </div>

            {/* Card Bottom Meta */}
            <div className="mt-8 pt-5 border-t border-slate-800 flex flex-wrap items-center justify-between gap-4 text-xs">
              <button
                onClick={onOpenMap}
                type="button"
                className="flex items-center gap-2 text-slate-300 hover:text-amber-400 transition-colors cursor-pointer group"
              >
                <MapPin className="w-4 h-4 text-amber-400 group-hover:scale-110 transition-transform" />
                <span className="underline decoration-slate-600 underline-offset-4 group-hover:decoration-amber-400">
                  {COMPANY_INFO.address}
                </span>
              </button>

              <div className="flex items-center gap-2 text-slate-300">
                <Clock className="w-4 h-4 text-amber-400" />
                <span>Plantão até 22:00h (Seg a Dom)</span>
              </div>
            </div>
          </div>

          {/* Right Column: Contrast Box (Curiosos vs Chaveiro Central) */}
          <div className="lg:col-span-5 flex flex-col gap-5 justify-between">
            
            {/* Top Warning Card (O Risco dos Curiosos) */}
            <div className="bg-[#171318] border border-red-900/50 rounded-2xl p-5 sm:p-6 shadow-sm">
              <div className="flex items-center gap-2 text-red-400 text-xs font-bold uppercase tracking-wider mb-2">
                <AlertTriangle className="w-4 h-4" />
                <span>O RISCO DOS CURIOSOS</span>
              </div>
              <div className="text-lg font-black text-white font-['Montserrat'] mb-2">
                Prejuízo de R$ 800 a R$ 3.000
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                Tentar arrombar com chave de fenda ou contratar quem não possui instrumental específico resulta em fechadura furada, batente quebrado, lataria de carro amassada e custos desnecessários de marcenaria e funilaria.
              </p>
            </div>

            {/* Bottom Guarantee Card (Padrão Chaveiro Central) */}
            <div className="bg-[#121826] border border-amber-500/50 rounded-2xl p-5 sm:p-6 shadow-[0_4px_24px_rgba(245,158,11,0.08)] flex-1 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider mb-2">
                  <ShieldCheck className="w-4 h-4" />
                  <span>PADRÃO CHAVEIRO CENTRAL</span>
                </div>
                <div className="text-lg font-black text-white font-['Montserrat'] mb-3">
                  Abertura Fina com Preservação da Estrutura
                </div>

                <ul className="space-y-2 text-xs text-slate-200">
                  <li className="flex items-start gap-2">
                    <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                    <span>Decodificação mecânica por palhetas internas (sem perfuração)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                    <span>Preservação total do cilindro original, maçaneta e batente</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                    <span>Conferência de identidade no local para proteção contra fraudes</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                    <span>Orçamento fixo antes de qualquer intervenção mecânica</span>
                  </li>
                </ul>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800 text-[11px] text-amber-400 font-semibold flex items-center justify-between">
                <span>Tempo médio de abertura técnica:</span>
                <span className="font-mono text-xs text-white">5 a 12 minutos</span>
              </div>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
