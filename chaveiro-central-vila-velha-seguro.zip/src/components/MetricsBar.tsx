import React from 'react';

export const MetricsBar: React.FC = () => {
  const metrics = [
    {
      value: '15-25 min',
      label: 'Chegada Estimada em Vila Velha (varia conforme demanda)',
    },
    {
      value: '22:00 hs',
      label: 'Plantão Pós-Comercial Todos os Dias',
    },
    {
      value: 'Sem danos',
      label: 'Técnicas Não-Destrutivas Sempre que Possível',
    },
    {
      value: '+18 anos',
      label: 'Experiência e Autoridade Consolidada',
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-16 lg:mb-24">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4">
        {metrics.map((metric, index) => (
          <div
            key={index}
            className="bg-[#121826] border border-slate-800/80 rounded-xl p-4 sm:p-6 text-center sm:text-left flex flex-col justify-between hover:border-slate-700 transition-colors"
          >
            <div className="text-2xl sm:text-3xl font-black text-amber-400 font-['Montserrat'] tracking-tight mb-1 tabular-nums">
              {metric.value}
            </div>
            <div className="text-xs sm:text-sm text-slate-300 font-medium leading-snug">
              {metric.label}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
