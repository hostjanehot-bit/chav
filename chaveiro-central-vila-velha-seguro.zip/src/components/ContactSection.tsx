import React, { useState } from 'react';
import { Phone, MapPin, Clock, MessageCircle, ExternalLink, ChevronDown, CheckCircle2 } from 'lucide-react';
import { COMPANY_INFO, NEIGHBORHOODS } from '../data/locksmithData';

interface ContactSectionProps {
  onOpenMap: () => void;
  preFilledNeighborhood?: string;
  preFilledService?: string;
}

export const ContactSection: React.FC<ContactSectionProps> = ({
  onOpenMap,
  preFilledNeighborhood,
  preFilledService,
}) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [neighborhood, setNeighborhood] = useState(preFilledNeighborhood || 'Centro de Vila Velha');
  const [service, setService] = useState(
    preFilledService || 'Abertura de Porta Residencial (Chave Esquecida/Trancada)'
  );
  const [notes, setNotes] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Keep synced if parent changes prefill
  React.useEffect(() => {
    if (preFilledNeighborhood) setNeighborhood(preFilledNeighborhood);
  }, [preFilledNeighborhood]);

  React.useEffect(() => {
    if (preFilledService) setService(preFilledService);
  }, [preFilledService]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setErrorMsg('Por favor, informe seu nome ou identificação.');
      return;
    }
    if (!phone.trim() || phone.trim().length < 8) {
      setErrorMsg('Por favor, informe um telefone ou WhatsApp com DDD para contato.');
      return;
    }

    setErrorMsg('');
    openWhatsApp();
    setSubmitted(true);
  };

  // O site não tem servidor: o chamado só é enviado quando a pessoa toca em "enviar" no WhatsApp.
  const openWhatsApp = () => {
    const text = encodeURIComponent(
      `Olá, Chaveiro Central! Gostaria de atendimento urgente.\nNome: ${name || 'Cliente'}\nTelefone: ${phone || 'Não informado'}\nBairro: ${neighborhood}\nServiço: ${service}${notes ? `\nDetalhes: ${notes}` : ''}`
    );
    window.open(`https://wa.me/${COMPANY_INFO.phoneWhatsAppClean}?text=${text}`, '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="contato" className="py-16 lg:py-24 bg-[#0B0F17]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-12 sm:mb-16">
          <div className="text-amber-400 font-bold text-xs uppercase tracking-widest mb-3">
            ATENDIMENTO IMEDIATO • VILA VELHA E VITÓRIA
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight mb-4 font-['Montserrat']">
            Entre em contato com o plantão operacional.
          </h2>
          <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
            Seja para uma emergência urgente ou agendamento programado, fale diretamente com nossa equipe. Atendimento imediato por telefone, WhatsApp ou pelo formulário abaixo.
          </p>
        </div>

        {/* Contact Split Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Card: Dados Oficiais de Atendimento */}
          <div className="lg:col-span-5 bg-[#121826] border border-slate-800 rounded-2xl p-6 sm:p-8 flex flex-col justify-between">
            <div>
              <h3 className="text-lg sm:text-xl font-bold text-white mb-6 font-['Montserrat']">
                Dados Oficiais de Atendimento
              </h3>

              <div className="space-y-5">
                {/* Emergency Cell & WhatsApp */}
                <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/40">
                  <div className="flex items-center gap-2 text-amber-400 text-[11px] font-bold uppercase tracking-wider mb-1">
                    <Phone className="w-4 h-4" />
                    <span>CELULAR &amp; WHATSAPP PLANTÃO (ATÉ 22H)</span>
                  </div>
                  <a
                    href={`tel:${COMPANY_INFO.phoneWhatsAppClean}`}
                    className="text-xl sm:text-2xl font-black text-white hover:text-amber-400 transition-colors font-['Montserrat'] block"
                  >
                    {COMPANY_INFO.phoneWhatsApp}
                  </a>
                  <span className="text-[11px] text-amber-300/80 mt-1 block">
                    Ligue com urgência para chamadas urgentes
                  </span>
                </div>

                {/* Landline */}
                <div className="flex items-start gap-3.5 p-3 rounded-xl bg-slate-900/60 border border-slate-800">
                  <div className="p-2 rounded-lg bg-slate-800 text-amber-400 shrink-0 mt-0.5">
                    <Phone className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                      TELEFONE COMERCIAL FIXO
                    </span>
                    <a
                      href={`tel:${COMPANY_INFO.phoneLandlineClean}`}
                      className="text-sm sm:text-base font-bold text-white hover:text-amber-400 transition-colors"
                    >
                      {COMPANY_INFO.phoneLandline}
                    </a>
                  </div>
                </div>

                {/* Hours */}
                <div className="flex items-start gap-3.5 p-3 rounded-xl bg-slate-900/60 border border-slate-800">
                  <div className="p-2 rounded-lg bg-slate-800 text-amber-400 shrink-0 mt-0.5">
                    <Clock className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                      HORÁRIO DO PLANTÃO
                    </span>
                    <div className="text-xs sm:text-sm font-semibold text-white">
                      {COMPANY_INFO.hours}
                    </div>
                    <div className="text-[11px] text-slate-400 mt-0.5">
                      {COMPANY_INFO.plantaoNotice}
                    </div>
                  </div>
                </div>

                {/* Address */}
                <div className="flex items-start gap-3.5 p-3 rounded-xl bg-slate-900/60 border border-slate-800">
                  <div className="p-2 rounded-lg bg-slate-800 text-amber-400 shrink-0 mt-0.5">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                      ENDEREÇO DA LOJA FÍSICA
                    </span>
                    <div className="text-xs sm:text-sm font-semibold text-white">
                      {COMPANY_INFO.address}
                    </div>
                    <div className="text-[11px] text-slate-400 mt-0.5">
                      {COMPANY_INFO.district}, {COMPANY_INFO.city} - {COMPANY_INFO.state}, {COMPANY_INFO.zip}
                    </div>
                  </div>
                </div>
              </div>

              {/* View on Google Maps button */}
              <button
                onClick={onOpenMap}
                type="button"
                className="mt-6 w-full py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-semibold text-slate-200 hover:text-white transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <MapPin className="w-3.5 h-3.5 text-amber-400" />
                <span>VER LOCALIZAÇÃO NO GOOGLE MAPS</span>
                <ExternalLink className="w-3 h-3 text-slate-400" />
              </button>
            </div>

            {/* Coverage Summary Box */}
            <div className="mt-6 pt-5 border-t border-slate-800 text-xs text-slate-300 space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-400">Área de Cobertura Principal:</span>
                <span className="text-white font-medium">{COMPANY_INFO.coverage}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Sede Operacional:</span>
                <span className="text-white font-medium">{COMPANY_INFO.district}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Raio de Atendimento:</span>
                <span className="text-white font-medium">{COMPANY_INFO.radius}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Principais Bairros:</span>
                <span className="text-amber-400 font-medium text-right">Praia da Costa, Itapuã, Glória, Terceira Ponte</span>
              </div>
            </div>
          </div>

          {/* Right Card: Solicitação de Atendimento / Orçamento */}
          <div className="lg:col-span-7 bg-[#121826] border border-slate-800 rounded-2xl p-6 sm:p-8">
            <h3 className="text-lg sm:text-xl font-bold text-white mb-2 font-['Montserrat']">
              Solicitação de Atendimento / Orçamento
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 mb-6">
              Preencha os campos abaixo: abriremos o WhatsApp com a mensagem pronta para você enviar à equipe de plantão.
            </p>

            {submitted ? (
              <div className="p-6 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-center space-y-3">
                <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto" />
                <h4 className="text-base sm:text-lg font-bold text-white font-['Montserrat']">
                  Falta só um passo: envie a mensagem no WhatsApp
                </h4>
                <p className="text-xs sm:text-sm text-slate-300">
                  Abrimos o WhatsApp com os seus dados prontos. Toque em <strong>enviar</strong> lá para concluir o chamado. Se a janela não abriu, ligue agora para{' '}
                  <a href={`tel:${COMPANY_INFO.phoneWhatsAppClean}`} className="font-bold text-amber-400 underline">
                    {COMPANY_INFO.phoneWhatsApp}
                  </a>.
                </p>
                <div className="pt-2">
                  <button
                    onClick={() => setSubmitted(false)}
                    type="button"
                    className="text-xs text-amber-400 underline font-medium cursor-pointer"
                  >
                    Enviar nova mensagem ou alterar dados
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                {errorMsg && (
                  <div className="p-3 rounded-lg bg-red-950/60 border border-red-500/50 text-red-200 text-xs">
                    {errorMsg}
                  </div>
                )}

                {/* Name */}
                <div>
                  <label htmlFor="field-name" className="block text-[11px] font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                    SEU NOME OU IDENTIFICAÇÃO
                  </label>
                  <input
                    id="field-name"
                    maxLength={80}
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Ex: Carlos Eduardo"
                    required
                    className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700/80 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 transition-colors"
                  />
                </div>

                {/* Phone & Neighborhood row */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="field-phone" className="block text-[11px] font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                      TELEFONE / WHATSAPP COM DDD
                    </label>
                    <input
                      id="field-phone"
                      maxLength={20}
                      type="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="(27) 99999-9999"
                      required
                      className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700/80 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 transition-colors"
                    />
                  </div>

                  <div>
                    <label htmlFor="field-neighborhood" className="block text-[11px] font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                      BAIRRO / LOCALIDADE
                    </label>
                    <div className="relative">
                      <select
                        id="field-neighborhood"
                        value={neighborhood}
                        onChange={(e) => setNeighborhood(e.target.value)}
                        className="w-full appearance-none px-4 py-3 rounded-xl bg-slate-900 border border-slate-700/80 text-white text-sm focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 transition-colors pr-10 cursor-pointer"
                      >
                        {NEIGHBORHOODS.map((item) => (
                          <option key={item.id} value={item.name} className="bg-slate-900 text-white">
                            {item.name}
                          </option>
                        ))}
                        <option value="Outro bairro em Vila Velha" className="bg-slate-900 text-white">
                          Outro bairro em Vila Velha
                        </option>
                        <option value="Outro município da Grande Vitória" className="bg-slate-900 text-white">
                          Outro município da Grande Vitória
                        </option>
                      </select>
                      <ChevronDown className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                    </div>
                  </div>
                </div>

                {/* Service Type */}
                <div>
                  <label htmlFor="field-service" className="block text-[11px] font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                    TIPO DE SERVIÇO REQUERIDO
                  </label>
                  <div className="relative">
                    <select
                      id="field-service"
                      value={service}
                      onChange={(e) => setService(e.target.value)}
                      className="w-full appearance-none px-4 py-3 rounded-xl bg-slate-900 border border-slate-700/80 text-white text-sm focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 transition-colors pr-10 cursor-pointer"
                    >
                      <option value="Abertura de Porta Residencial (Chave Esquecida/Trancada)" className="bg-slate-900 text-white">
                        Abertura de Porta Residencial (Chave Esquecida/Trancada)
                      </option>
                      <option value="Abertura Automotiva / Chave Presa" className="bg-slate-900 text-white">
                        Abertura Automotiva / Chave Presa
                      </option>
                      <option value="Troca / Cópia de Segredo de Cilindro" className="bg-slate-900 text-white">
                        Troca / Cópia de Segredo de Cilindro
                      </option>
                      <option value="Abertura de Cofre / Recuperação de Segredo" className="bg-slate-900 text-white">
                        Abertura de Cofre / Recuperação de Segredo
                      </option>
                      <option value="Instalação de Fechadura Digital / Eletrônica" className="bg-slate-900 text-white">
                        Instalação de Fechadura Digital / Eletrônica
                      </option>
                      <option value="Chave Mestra Corporativa" className="bg-slate-900 text-white">
                        Chave Mestra Corporativa
                      </option>
                      <option value="Chave Quebrada no Tambor" className="bg-slate-900 text-white">
                        Chave Quebrada no Tambor
                      </option>
                    </select>
                    <ChevronDown className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  </div>
                </div>

                {/* Additional Notes */}
                <div>
                  <label htmlFor="field-notes" className="block text-[11px] font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                    INFORMAÇÕES ADICIONAIS (OPCIONAL)
                  </label>
                  <textarea
                    maxLength={500}
                    id="field-notes"
                    rows={3}
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Ex: Porta de madeira maciça com fechadura tetra; ou modelo do carro e ano..."
                    className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700/80 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 transition-colors resize-none"
                  />
                </div>

                {/* Form Buttons */}
                <div className="pt-2 flex flex-col sm:flex-row gap-3">
                  <button
                    type="submit"
                    className="flex-1 py-3 px-5 text-xs sm:text-sm font-extrabold uppercase tracking-wider text-slate-950 bg-amber-400 hover:bg-amber-300 active:bg-amber-500 rounded-xl transition-all shadow-[0_2px_12px_rgba(245,158,11,0.25)] flex items-center justify-center gap-2 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-400"
                  >
                    <MessageCircle className="w-4 h-4 stroke-[2.2]" />
                    <span>ENVIAR PELO WHATSAPP</span>
                  </button>
                </div>

                {/* Privacy note */}
                <p className="text-[10px] text-slate-500 pt-1 text-center sm:text-left">
                  Ao enviar, seus dados seguem para o nosso WhatsApp e são usados só para o atendimento. Este site não guarda o que você digita. Veja a{' '}
                  <a href="/privacidade.html" target="_blank" rel="noopener noreferrer" className="underline hover:text-amber-400">
                    Política de Privacidade
                  </a>.
                </p>
              </form>
            )}
          </div>

        </div>
      </div>
    </section>
  );
};
