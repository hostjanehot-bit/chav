import React from 'react';
import carImg from '../assets/images/service-car.webp';
import lockImg from '../assets/images/service-lock.webp';
import safeImg from '../assets/images/service-safe.webp';
import { ArrowRight, CheckCircle2, Shield, Building2, Key, Car, Lock } from 'lucide-react';

interface ServicesGridProps {
  onSelectService: (serviceName: string) => void;
}

export const ServicesGrid: React.FC<ServicesGridProps> = ({ onSelectService }) => {
  return (
    <section id="servicos" className="py-16 lg:py-24 bg-[#0B0F17]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-12 sm:mb-16">
          <div className="text-amber-400 font-bold text-xs uppercase tracking-widest mb-3">
            SERVIÇOS ESPECIALIZADOS • TÉCNICAS NÃO-DESTRUTIVAS
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight mb-4 font-['Montserrat']">
            Engenharia de precisão para cada tipo de travamento.
          </h2>
          <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
            Não arrisque danificar sua porta, veículo ou patrimônio com tentativas amadoras. Utilizamos instrumental cirúrgico desenvolvido para abrir e codificar mecanismos buscando não deixar marcas.
          </p>
        </div>

        {/* 2x2 Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-10">
          
          {/* 01: Automotivo */}
          <div className="bg-[#121826] border border-slate-800 rounded-2xl p-6 sm:p-8 flex flex-col justify-between hover:border-slate-700 transition-all group">
            <div>
              {/* Header Badge */}
              <div className="flex items-center justify-between text-xs text-slate-400 pb-3 border-b border-slate-800/80 mb-4">
                <span className="font-mono font-bold text-amber-400 text-sm">01</span>
                <span className="font-medium text-slate-300">Veículos Nacionais &amp; Importados</span>
              </div>

              {/* Title & Description */}
              <h3 className="text-xl sm:text-2xl font-bold text-white mb-3 font-['Montserrat'] group-hover:text-amber-400 transition-colors">
                Abertura e Codificação Automotiva
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-5">
                Abertura técnica veicular sem forçar borrachas, entortar colunas ou disparar alarmes. Confecção de chaves pantográficas, leitura e reprogramação de chips transponder e smart keys de presença para veículos de todas as montadoras.
              </p>

              {/* Image */}
              <div className="aspect-[16/9] w-full rounded-xl overflow-hidden bg-slate-900 mb-6 border border-slate-800">
                <img
                  src={carImg}
                  alt="Abertura e Codificação Automotiva com chave presencial smart key"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
              </div>

              {/* Bullet Points */}
              <ul className="space-y-2.5 text-xs text-slate-300 mb-6">
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <span>Abertura veicular sem risco de danos na lataria ou vedação da porta</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <span>Codificação de chaves canivete e chaves de presença presenciais</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <span>Leitura de imobilizador (ECU/BCM) direto no local</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <span>Atendimento no local para carros bloqueados na garagem ou na rua</span>
                </li>
              </ul>
            </div>

            {/* Card Footer */}
            <div className="pt-4 border-t border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <span className="text-[11px] text-slate-400">
                Tecnologia de ponta: Lishi e programadores OBD-II de última geração.
              </span>
              <button
                onClick={() => onSelectService('Abertura Automotiva / Chave Presa')}
                type="button"
                className="inline-flex items-center gap-1.5 font-bold text-amber-400 hover:text-amber-300 transition-colors uppercase tracking-wider shrink-0 cursor-pointer self-start sm:self-auto"
              >
                <span>SOLICITAR SOCORRO AUTOMOTIVO</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* 02: Residencial & Digital */}
          <div className="bg-[#121826] border border-slate-800 rounded-2xl p-6 sm:p-8 flex flex-col justify-between hover:border-slate-700 transition-all group">
            <div>
              {/* Header Badge */}
              <div className="flex items-center justify-between text-xs text-slate-400 pb-3 border-b border-slate-800/80 mb-4">
                <span className="font-mono font-bold text-amber-400 text-sm">02</span>
                <span className="font-medium text-slate-300">Residências e Apartamentos</span>
              </div>

              {/* Title & Description */}
              <h3 className="text-xl sm:text-2xl font-bold text-white mb-3 font-['Montserrat'] group-hover:text-amber-400 transition-colors">
                Fechaduras Residenciais &amp; Digitais
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-5">
                Soluções completas para travamentos acidentais de portas de entrada, fechaduras tetra, cilindros de perfil europeu e fechaduras biométricas/eletrônicas. Troca rápida de cilindros e alteração de segredo com novas chaves lacradas entregues em mãos.
              </p>

              {/* Image */}
              <div className="aspect-[16/9] w-full rounded-xl overflow-hidden bg-slate-900 mb-6 border border-slate-800">
                <img
                  src={lockImg}
                  alt="Fechadura digital residencial com teclado numérico e biometria"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
              </div>

              {/* Bullet Points */}
              <ul className="space-y-2.5 text-xs text-slate-300 mb-6">
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <span>Aberturas não destrutivas sem precisar furar ou destruir a maçaneta</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <span>Instalação e configuração de fechaduras eletrônicas e digitais</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <span>Troca imediata de segredo com chaves multiponto de alta resistência</span>
                </li>
              </ul>
            </div>

            {/* Card Footer */}
            <div className="pt-4 border-t border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <span className="text-[11px] text-slate-400">
                Atendimento urgente para quem ficou trancado por fora.
              </span>
              <button
                onClick={() => onSelectService('Abertura de Porta Residencial (Chave Esquecida/Trancada)')}
                type="button"
                className="inline-flex items-center gap-1.5 font-bold text-amber-400 hover:text-amber-300 transition-colors uppercase tracking-wider shrink-0 cursor-pointer self-start sm:self-auto"
              >
                <span>CHAMAR PARA RESIDÊNCIA</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* 03: Cofres & Blindagens */}
          <div className="bg-[#121826] border border-slate-800 rounded-2xl p-6 sm:p-8 flex flex-col justify-between hover:border-slate-700 transition-all group">
            <div>
              {/* Header Badge */}
              <div className="flex items-center justify-between text-xs text-slate-400 pb-3 border-b border-slate-800/80 mb-4">
                <span className="font-mono font-bold text-amber-400 text-sm">03</span>
                <span className="font-medium text-slate-300">Segurança Institucional e Pessoal</span>
              </div>

              {/* Title & Description */}
              <h3 className="text-xl sm:text-2xl font-bold text-white mb-3 font-['Montserrat'] group-hover:text-amber-400 transition-colors">
                Cofres &amp; Blindagens de Alta Segurança
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-5">
                Especialidade cirúrgica em abertura técnica de cofres comerciais, residenciais e bancários trancados. Recuperação de combinação numérica, reprogramação de módulos digitais eletrônicos e destravamento mecânico buscando preservar a estrutura do cofre.
              </p>

              {/* Image */}
              <div className="aspect-[16/9] w-full rounded-xl overflow-hidden bg-slate-900 mb-6 border border-slate-800">
                <img
                  src={safeImg}
                  alt="Abertura técnica cirúrgica de cofres e caixas fortes blindadas"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
              </div>

              {/* Bullet Points */}
              <ul className="space-y-2.5 text-xs text-slate-300 mb-6">
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <span>Abertura técnica de segredos mecânicos e teclados numéricos</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <span>Preservação estrutural do gabinete e dos mecanismos de segurança</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <span>Recuperação ou alteração de código segredo com sigilo absoluto</span>
                </li>
              </ul>
            </div>

            {/* Card Footer */}
            <div className="pt-4 border-t border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <span className="text-[11px] text-slate-400">
                Sigilo ético e confidencialidade no atendimento.
              </span>
              <button
                onClick={() => onSelectService('Abertura de Cofre / Recuperação de Segredo')}
                type="button"
                className="inline-flex items-center gap-1.5 font-bold text-amber-400 hover:text-amber-300 transition-colors uppercase tracking-wider shrink-0 cursor-pointer self-start sm:self-auto"
              >
                <span>ABERTURA TÉCNICA DE COFRES</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* 04: Sistemas de Chave Mestra & Travamento Comercial */}
          <div className="bg-[#121826] border border-slate-800 rounded-2xl p-6 sm:p-8 flex flex-col justify-between hover:border-slate-700 transition-all group">
            <div>
              {/* Header Badge */}
              <div className="flex items-center justify-between text-xs text-slate-400 pb-3 border-b border-slate-800/80 mb-4">
                <span className="font-mono font-bold text-amber-400 text-sm">04</span>
                <span className="font-medium text-slate-300">Empresas, Clínicas e Condomínios</span>
              </div>

              {/* Title & Description */}
              <h3 className="text-xl sm:text-2xl font-bold text-white mb-3 font-['Montserrat'] group-hover:text-amber-400 transition-colors">
                Sistemas de Chave Mestra &amp; Travamento Comercial
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-5">
                Projetos e implementação de planos de mestragem para controle hierárquico de acessos. Uma única chave mestre abre todos os setores autorizados para a diretoria ou zeladoria, enquanto cada funcionário ou condômino acessa apenas a sua respectiva porta.
              </p>

              {/* Corporate Applications Box */}
              <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 mb-6">
                <span className="text-[10px] uppercase font-bold tracking-wider text-amber-400 block mb-2.5">
                  APLICAÇÕES CORPORATIVAS EM VILA VELHA:
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-300">
                  <div className="flex items-center gap-1.5">
                    <Building2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span>Edifícios comerciais e condomínios</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Building2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span>Lojas e centros de compras na Glória</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Building2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span>Clínicas, consultórios e hospitais</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Building2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span>Escritórios de advocacia e contabilidade</span>
                  </div>
                </div>
              </div>

              {/* Bullet Points */}
              <ul className="space-y-2.5 text-xs text-slate-300 mb-6">
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <span>Chaves patenteadas com proteção contra cópia não autorizada</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <span>Barras antipânico e molas aéreas para rotas de fuga</span>
                </li>
              </ul>
            </div>

            {/* Card Footer */}
            <div className="pt-4 border-t border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <span className="text-[11px] text-slate-400">
                Contratos corporativos e controle de rotas livres.
              </span>
              <button
                onClick={() => onSelectService('Chave Mestra Corporativa')}
                type="button"
                className="inline-flex items-center gap-1.5 font-bold text-amber-400 hover:text-amber-300 transition-colors uppercase tracking-wider shrink-0 cursor-pointer self-start sm:self-auto"
              >
                <span>SOLICITAR PROPOSTA COMERCIAL</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
