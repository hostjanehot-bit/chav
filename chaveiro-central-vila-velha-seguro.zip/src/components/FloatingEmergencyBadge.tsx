import React, { useState } from 'react';
import { MessageCircle, Phone, X, ChevronUp, Clock, AlertCircle } from 'lucide-react';
import { COMPANY_INFO } from '../data/locksmithData';

export const FloatingEmergencyBadge: React.FC = () => {
  const [minimized, setMinimized] = useState(false);

  const handleWhatsApp = () => {
    const text = encodeURIComponent(
      'Olá, Chaveiro Central! Preciso de socorro emergencial urgente. Poderia me atender?'
    );
    window.open(`https://wa.me/${COMPANY_INFO.phoneWhatsAppClean}?text=${text}`, '_blank', 'noopener,noreferrer');
  };

  if (minimized) {
    return (
      <div className="fixed bottom-4 right-4 z-50">
        <button
          onClick={() => setMinimized(false)}
          type="button"
          className="flex items-center gap-2 px-4 py-2.5 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-2xl transition-all transform hover:scale-105 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400"
          aria-label="Expandir plantão de emergência"
        >
          <MessageCircle className="w-4 h-4 fill-current" />
          <span>Plantão até 22h</span>
          <ChevronUp className="w-3.5 h-3.5" />
        </button>
      </div>
    );
  }

  return (
    <div className="fixed bottom-4 right-4 z-50 max-w-xs sm:max-w-sm w-full mx-4 sm:mx-0 shadow-2xl animate-in fade-in slide-in-from-bottom-4 duration-300">
      <div className="bg-[#0f172a] border border-emerald-500/50 rounded-2xl p-4 sm:p-4.5 text-white shadow-[0_12px_36px_rgba(0,0,0,0.7)] backdrop-blur-md">
        
        {/* Header with minimize button */}
        <div className="flex items-center justify-between gap-2 pb-2.5 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
            </span>
            <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-400">
              Plantão Chaveiro Central
            </span>
          </div>

          <button
            onClick={() => setMinimized(true)}
            type="button"
            className="text-slate-400 hover:text-white p-1 rounded-md transition-colors"
            title="Minimizar"
            aria-label="Minimizar aviso"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Content */}
        <div className="py-2.5 text-xs text-slate-300 leading-relaxed">
          <p className="font-medium text-slate-100">
            Precisa de socorro imediato?
          </p>
          <p className="text-[11px] text-slate-400 mt-0.5">
            Nosso plantonista atende de segunda a domingo até às <strong className="text-white">22:00hs</strong>.
          </p>
          <div className="mt-2 text-[11px] text-slate-300 space-y-0.5">
            <div>WhatsApp: <strong className="text-emerald-400">{COMPANY_INFO.phoneWhatsApp}</strong></div>
            <div>Fixo: <strong className="text-slate-200">{COMPANY_INFO.phoneLandline}</strong></div>
          </div>
        </div>

        {/* Actions */}
        <div className="pt-2 flex items-center gap-2">
          <button
            onClick={handleWhatsApp}
            type="button"
            className="flex-1 py-2 px-3 text-xs font-bold text-slate-950 bg-emerald-400 hover:bg-emerald-300 active:bg-emerald-500 rounded-lg transition-colors flex items-center justify-center gap-1.5 shadow-md cursor-pointer"
          >
            <MessageCircle className="w-3.5 h-3.5 fill-current" />
            <span>FALAR NO WHATSAPP</span>
          </button>

          <a
            href={`tel:${COMPANY_INFO.phoneWhatsAppClean}`}
            className="p-2 text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
            title="Ligar agora"
            aria-label="Ligar para o plantão"
          >
            <Phone className="w-4 h-4 text-amber-400" />
          </a>
        </div>

      </div>
    </div>
  );
};
