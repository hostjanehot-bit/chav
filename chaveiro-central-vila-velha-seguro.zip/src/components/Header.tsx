import React, { useState } from 'react';
import { KeyRound, Menu, X, PhoneCall } from 'lucide-react';
import { COMPANY_INFO } from '../data/locksmithData';

interface HeaderProps {
  onContactClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onContactClick }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { label: 'Início', href: '#inicio' },
    { label: 'Serviços', href: '#servicos' },
    { label: 'Sobre', href: '#sobre' },
    { label: 'Contato', href: '#contato' },
  ];

  return (
    <header className="sticky top-0 z-40 w-full bg-[#0B0F17]/95 backdrop-blur-md border-b border-slate-800/80 transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-4">
        {/* Zone 1: Brand Wordmark */}
        <a
          href="#inicio"
          className="flex items-center gap-2.5 text-white font-extrabold tracking-tight text-lg sm:text-xl shrink-0 group focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-400 rounded-lg px-1 py-0.5"
        >
          <span className="w-9 h-9 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 group-hover:bg-amber-500 group-hover:text-slate-950 transition-colors shadow-sm">
            <KeyRound className="w-5 h-5 stroke-[2.2]" />
          </span>
          <span className="font-['Montserrat'] tracking-tight">
            Chaveiro <span className="text-amber-400">Central</span>
          </span>
        </a>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-300">
          {navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              className="hover:text-amber-400 transition-colors whitespace-nowrap py-1 focus:outline-none focus-visible:text-amber-400"
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* Zone 3: Primary Action CTA */}
        <div className="hidden sm:flex items-center gap-3 shrink-0">
          <a
            href={`tel:${COMPANY_INFO.phoneWhatsAppClean}`}
            className="flex items-center gap-2 text-xs font-semibold text-slate-300 hover:text-white bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-full px-3.5 py-2 transition-colors whitespace-nowrap"
          >
            <PhoneCall className="w-3.5 h-3.5 text-amber-400" />
            <span>(27) 99281-2258</span>
          </a>
          <button
            onClick={onContactClick}
            type="button"
            className="px-5 py-2 text-xs font-bold uppercase tracking-wider text-slate-950 bg-amber-400 hover:bg-amber-300 active:bg-amber-500 rounded-full shadow-[0_2px_12px_rgba(245,158,11,0.25)] transition-all transform hover:-translate-y-0.5 whitespace-nowrap focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-400 focus-visible:ring-offset-2 focus-visible:ring-offset-slate-950"
          >
            Entrar em Contato
          </button>
        </div>

        {/* Mobile menu trigger */}
        <div className="flex md:hidden items-center gap-2">
          <button
            onClick={onContactClick}
            type="button"
            className="px-3.5 py-1.5 text-xs font-bold uppercase text-slate-950 bg-amber-400 rounded-full"
          >
            Contato
          </button>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            type="button"
            className="p-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-400"
            aria-label="Alternar navegação"
            aria-expanded={mobileMenuOpen}
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-b border-slate-800 bg-[#0B0F17] px-4 pt-3 pb-5 space-y-3">
          <div className="flex flex-col space-y-2">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="px-3 py-2 rounded-md text-sm font-medium text-slate-200 hover:bg-slate-800 hover:text-amber-400 transition-colors"
              >
                {link.label}
              </a>
            ))}
          </div>
          <div className="pt-3 border-t border-slate-800 flex flex-col gap-2.5">
            <a
              href={`tel:${COMPANY_INFO.phoneWhatsAppClean}`}
              className="flex items-center justify-center gap-2 text-sm font-semibold text-slate-200 bg-slate-900 border border-slate-700 rounded-lg py-2.5"
            >
              <PhoneCall className="w-4 h-4 text-amber-400" />
              <span>Plantão: (27) 99281-2258</span>
            </a>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onContactClick();
              }}
              type="button"
              className="w-full text-center py-2.5 text-xs font-bold uppercase tracking-wider text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-lg shadow-md"
            >
              Entrar em Contato
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
