import React from 'react';
import { X, MapPin, Navigation, ExternalLink, Copy, Check, Clock, Phone } from 'lucide-react';
import { COMPANY_INFO } from '../data/locksmithData';

interface MapsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MapsModal: React.FC<MapsModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = React.useState(false);

  if (!isOpen) return null;

  const fullAddress = `${COMPANY_INFO.address}, ${COMPANY_INFO.district}, ${COMPANY_INFO.city} - ${COMPANY_INFO.state}, CEP ${COMPANY_INFO.zip}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(fullAddress);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
    `Chaveiro Central Vila Velha ${fullAddress}`
  )}`;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
    >
      <div
        className="bg-[#121826] border border-slate-700 w-full max-w-lg rounded-2xl p-6 shadow-2xl relative text-slate-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-lg bg-amber-500/10 text-amber-400">
              <MapPin className="w-5 h-5" />
            </span>
            <div>
              <h3 className="font-bold text-white text-base font-['Montserrat']">
                Base Operacional &amp; Loja Física
              </h3>
              <p className="text-xs text-slate-400">Chaveiro Central - Vila Velha</p>
            </div>
          </div>
          <button
            onClick={onClose}
            type="button"
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
            aria-label="Fechar modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="py-5 space-y-4 text-xs sm:text-sm">
          {/* Simulated Satellite/Map View Header */}
          <div className="w-full h-44 rounded-xl overflow-hidden bg-slate-900 border border-slate-800 relative flex flex-col items-center justify-center p-4 text-center">
            {/* Background Grid Pattern */}
            <div
              className="absolute inset-0 opacity-20 pointer-events-none"
              style={{
                backgroundImage:
                  'radial-gradient(circle at 1px 1px, #f59e0b 1px, transparent 0)',
                backgroundSize: '24px 24px',
              }}
            />
            
            <div className="relative z-10 flex flex-col items-center">
              <div className="w-12 h-12 rounded-full bg-amber-500/20 border border-amber-400 text-amber-400 flex items-center justify-center mb-2 shadow-[0_0_20px_rgba(245,158,11,0.3)] animate-bounce">
                <MapPin className="w-6 h-6" />
              </div>
              <span className="font-bold text-white text-sm font-['Montserrat']">
                {COMPANY_INFO.address}
              </span>
              <span className="text-xs text-slate-300">
                {COMPANY_INFO.district}, {COMPANY_INFO.city} - {COMPANY_INFO.state}
              </span>
              <span className="text-[11px] text-amber-400 font-medium mt-1">
                Rota direta para Terceira Ponte, Praia da Costa e Glória
              </span>
            </div>
          </div>

          {/* Address Details */}
          <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
            <div className="flex items-start justify-between gap-2">
              <div className="text-xs text-slate-300">
                <strong className="text-white block">{fullAddress}</strong>
                <span className="text-[11px] text-slate-400">Ponto de referência: Próximo ao cruzamento com Av. Champagnat</span>
              </div>
              <button
                onClick={handleCopy}
                type="button"
                className="p-2 text-slate-300 hover:text-amber-400 hover:bg-slate-800 rounded-lg transition-colors shrink-0"
                title="Copiar endereço"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center gap-2">
              <Clock className="w-4 h-4 text-amber-400 shrink-0" />
              <div>
                <span className="text-slate-400 block text-[10px]">PLANTÃO</span>
                <span className="text-white font-medium">Seg a Dom até 22h</span>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center gap-2">
              <Phone className="w-4 h-4 text-amber-400 shrink-0" />
              <div>
                <span className="text-slate-400 block text-[10px]">SOCORRO RÁPIDO</span>
                <span className="text-white font-medium">{COMPANY_INFO.phoneWhatsApp}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="pt-3 border-t border-slate-800 flex flex-col sm:flex-row gap-2.5">
          <a
            href={mapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex-1 py-2.5 px-4 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-colors shadow-md"
          >
            <Navigation className="w-3.5 h-3.5" />
            <span>Abrir no Google Maps</span>
            <ExternalLink className="w-3 h-3 text-slate-800" />
          </a>

          <button
            onClick={onClose}
            type="button"
            className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
