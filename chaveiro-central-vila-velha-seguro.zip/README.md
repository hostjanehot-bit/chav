# Chaveiro Central Vila Velha

Site estático (Vite + React + Tailwind). Não tem backend nem banco de dados: os formulários abrem o WhatsApp com a mensagem pronta.

## Rodar no seu computador
```
npm install
npm run dev
```

## Gerar a versão para publicar
```
npm install          # cria o package-lock.json; guarde esse arquivo
npm audit            # confira se há vulnerabilidades conhecidas
npm run build        # gera a pasta dist/
```
Publique o conteúdo de `dist/`.

## Onde hospedar
- **Netlify ou Cloudflare Pages** (mais simples): usam `public/_headers` e ativam HTTPS sozinhos.
- **Vercel**: usa `vercel.json`.
- **Hospedagem compartilhada (cPanel/Apache)**: envie o conteúdo de `dist/` (o `.htaccess` vai junto). Ative o SSL no painel antes.
- **VPS com nginx**: veja `docs/nginx.conf.example`.

## Antes de publicar
1. Preencha `legalName` e `cnpj` em `src/data/locksmithData.ts` (aparecem no rodapé).
2. Confirme os textos: "+18 anos", tempos de chegada e "sem danos sempre que possível" precisam ser verdadeiros.
3. Revise `public/privacidade.html` (pode ser conferida por um advogado ou contador).
4. Ative o HTTPS e só depois confira os cabeçalhos: `python check_headers.py https://seudominio.com.br`.
5. Ative verificação em duas etapas na conta do domínio e da hospedagem.
